import { useState, useEffect } from 'react';
import { Collection } from '@/types/collection';
import { ProductNode } from '@/types/product';

const useCollectionForm = (initialCollection?: Collection) => {
  const [name, setName] = useState(initialCollection?.name || '');
  const [description, setDescription] = useState(initialCollection?.description || '');
  const [products, setProducts] = useState<ProductNode[]>([]);
  const [seoTitle, setSeoTitle] = useState(initialCollection?.seoTitle || '');
  const [seoDescription, setSeoDescription] = useState(initialCollection?.seoDescription || '');
  const [bannerImage, setBannerImage] = useState(initialCollection?.bannerImage || '');
  const [isVisible, setIsVisible] = useState<boolean>(initialCollection?.isVisible ?? true);
  const [rules, setRules] = useState(initialCollection?.rules || { productType: '', vendor: '', tags: [], priceRange: { min: 0, max: 0 } });
  const [sortOrder, setSortOrder] = useState(initialCollection?.sortOrder || 0);

  useEffect(() => {
    if (initialCollection?.products?.length && typeof initialCollection.products[0] === 'string') {
      const fetchProducts = async () => {
        try {
          const productIds = initialCollection.products as string[];
          const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/products?ids=${productIds.join(',')}`);
          const fetchedProducts: ProductNode[] = await response.json();
          setProducts(fetchedProducts);
        } catch (error) {
          console.error('Error fetching product details:', error);
        }
      };
      fetchProducts();
    } else if (initialCollection?.products) {
      setProducts(initialCollection.products as ProductNode[]);
    }
  }, [initialCollection]);

  const handleSave = async () => {
    const payload: Collection = {
      name,
      description,
      products: products.map(product => product.id),
      seoTitle,
      seoDescription,
      bannerImage,
      isVisible,
      sortOrder,
      rules,
    };

    const method = initialCollection ? 'PUT' : 'POST';
    const url = initialCollection
      ? `${process.env.NEXT_PUBLIC_API_URL}/collections/${initialCollection._id}`
      : `${process.env.NEXT_PUBLIC_API_URL}/collections`;

    try {
      await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });
      alert('Collection saved successfully');
    } catch (error) {
      console.error('Error saving collection:', error);
    }
  };

  return {
    name,
    setName,
    description,
    setDescription,
    products,
    setProducts,
    seoTitle,
    setSeoTitle,
    seoDescription,
    setSeoDescription,
    bannerImage,
    setBannerImage,
    isVisible,
    setIsVisible,
    sortOrder,
    setSortOrder,
    rules,
    setRules,
    handleSave,
  };
};

export default useCollectionForm;
