import { useState, useEffect } from 'react';
import { Collection } from '@/types/collection';

const useCollections = (collectionId?: string) => {
  const [collections, setCollections] = useState<Collection[]>([]); // Ensure this is an array
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCollections = async () => {
      setLoading(true);
      try {
        const url = collectionId 
          ? `${process.env.NEXT_PUBLIC_API_URL}/collections/${collectionId}` 
          : `${process.env.NEXT_PUBLIC_API_URL}/collections`;

        const res = await fetch(url);
        if (!res.ok) throw new Error('Failed to fetch collection data');
        const data = await res.json();

        if (collectionId) {
          setCollections([data.collection]); // Wrap single collection in array
        } else {
          setCollections(data.collections || []); // Return array of collections
        }
      } catch (err: unknown) {
        if (err instanceof Error) {
          setError(err.message);
        } else {
          setError('An unknown error occurred');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchCollections();
  }, [collectionId]);

  return { collections, loading, error }; // Return 'collections' as an array
};

export default useCollections;
