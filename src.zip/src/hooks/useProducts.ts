import { useEffect, useState } from 'react';
import { ProductNode } from '@/types/product';

interface UseProductsOptions {
  search?: string;
  sortKey?: 'TITLE' | 'PRODUCT_TYPE' | 'VENDOR' | 'CREATED_AT' | 'UPDATED_AT' | 'PUBLISHED_AT';
  reverse?: boolean;
  first?: number;
  after?: string;
}

interface UseProductsResult {
  products: ProductNode[];
  pageInfo: {
    hasNextPage: boolean;
    endCursor: string;
  } | null;
  loading: boolean;
  error: string | null;
}

const useProducts = (options: UseProductsOptions = {}): UseProductsResult => {
  const [products, setProducts] = useState<ProductNode[]>([]);
  const [pageInfo, setPageInfo] = useState<{
    hasNextPage: boolean;
    endCursor: string;
  } | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      setError(null);

      const {
        search = '',
        sortKey = 'TITLE',
        reverse = false,
        first = 10,
        after,
      } = options;

      const queryParams = new URLSearchParams({
        search,
        sortKey,
        reverse: reverse.toString(),
        first: first.toString(),
      });

      if (after) {
        queryParams.append('after', after);
      }

      try {
        const res = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/products?${queryParams.toString()}`
        );
        if (!res.ok) {
          throw new Error('Failed to fetch products');
        }

        const data = await res.json();
        setProducts(data.products);
        setPageInfo(data.pageInfo);
      } catch (err: unknown) {
        if (err instanceof Error) {
          setError(err.message);
        } else {
          setError('An unknown error occurred');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [options]);

  return { products, pageInfo, loading, error };
};

export default useProducts;
