"use client";
import React, { createContext, useContext, useEffect, useState } from 'react';
import { useMediaQuery } from 'react-responsive';

interface ScreenContextProps {
  isMobile: boolean;
  isTablet: boolean;
  isDesktop: boolean;
}

// Create the context
const ScreenContext = createContext<ScreenContextProps | undefined>(undefined);

// ScreenProvider component that uses react-responsive to detect screen sizes
export const ScreenProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true); // Ensures client-side execution only
  }, []);

  // Always call hooks; only use the results when on the client
  const isMobileQuery = useMediaQuery({ maxWidth: 767 });
  const isTabletQuery = useMediaQuery({ minWidth: 768, maxWidth: 1024 });
  const isDesktopQuery = useMediaQuery({ minWidth: 1025 });

  // Ensure these values are only used when running on the client
  const isMobile = isClient && isMobileQuery;
  const isTablet = isClient && isTabletQuery;
  const isDesktop = isClient && isDesktopQuery;

  return (
    <ScreenContext.Provider value={{ isMobile, isTablet, isDesktop }}>
      {children}
    </ScreenContext.Provider>
  );
};

// Custom hook to use screen context
export const useScreen = (): ScreenContextProps => {
  const context = useContext(ScreenContext);
  if (!context) {
    throw new Error('useScreen must be used within a ScreenProvider');
  }
  return context;
};
