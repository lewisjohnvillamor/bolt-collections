// src/app/contact/page.tsx (Server Component)

import ContactPage from "@/components/ContactPage/ContactPage";

// Assuming your client component is ContactPage

// Server Component for SSR
export default async function Contact() {
  // Fetch your server-side data here (e.g., from an API or database)
  const serverData = "Support provided by Battery Plus"; // Example static server-side data

  // You can pass serverData as a prop to your client component
  return <ContactPage serverData={serverData} />;
}
