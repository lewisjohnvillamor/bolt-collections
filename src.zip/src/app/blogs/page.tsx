import React from 'react';

// Sample data for the blog post
const blogPost = {
  title: '5 Must-Have Car Accessories for the Modern Driver',
  date: 'September 25, 2024',
  author: 'Catherine Tanaquil',
  content:
    'As cars become more advanced, so do the accessories that enhance our driving experience. Here are five must-have car accessories that every modern driver should consider. A smartphone car mount allows you to stay hands-free while using your phone\'s GPS or managing calls. A portable car vacuum keeps your car’s interior clean with its compact and powerful design. A Bluetooth tire pressure monitoring system lets you monitor your tire pressure wirelessly for improved safety and fuel efficiency. Custom-fit floor mats protect your car’s interior and add a touch of style. Lastly, a dash camera records your journey for added safety and insurance purposes. Investing in these accessories will not only make your drive more enjoyable but can also save you time, money, and ensure a safe journey.',
  featuredImage: 'https://maranello-theme.myshopify.com/cdn/shop/articles/guide05.jpg?v=1683301583&width=2000',
};

const BlogPost = () => {
  return (
    <div className="bg-white pt-8 pb-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Featured Image */}
          <img
            src={blogPost.featuredImage}
            alt={blogPost.title}
            className="w-full h-auto object-cover mb-6 rounded-lg"
          />
          {/* Date and Author */}
          <div className="text-gray-500 text-sm mb-2">
            {blogPost.date} • {blogPost.author}
          </div>
          {/* Title */}
          <h1 className="text-3xl lg:text-4xl font-bold mb-6">{blogPost.title}</h1>
          {/* Content */}
          <p className="text-lg leading-relaxed text-gray-700 mb-10">{blogPost.content}</p>

          {/* Comment Section */}
          <div className="bg-gray-100 p-6 rounded-lg shadow-md">
            <h3 className="text-2xl font-semibold mb-4">Leave a comment</h3>
            <form>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium mb-1" htmlFor="name">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-red-600"
                    placeholder="Name"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1" htmlFor="email">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-red-600"
                    placeholder="Email"
                    required
                  />
                </div>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium mb-1" htmlFor="comment">
                  Comment
                </label>
                <textarea
                  id="comment"
                  className="w-full p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-red-600"
                  placeholder="Comment"
                  rows={4}
                  required
                ></textarea>
              </div>
              <p className="text-xs text-gray-500 mb-4">
                Please note, comments need to be approved before they are published.
              </p>
              <button className="bg-red-600 text-white py-3 px-6 rounded-md hover:bg-red-700 transition duration-200">
                Post comment
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogPost;
