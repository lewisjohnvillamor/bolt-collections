import BatteryFinder from '@/components/BatteryFinder/BatteryFinder';
import CategoriesType0 from '@/components/Categories/CategoriesType0';
import CategoryFeaturedOffers from '@/components/Categories/CategoryFeaturedOffers';
import CategoryPage from '@/components/Categories/CategoryPage';
import HeroSlider from '@/components/HeroSlider';
import AmazingDeals from '@/components/Layout/AmazingDeals';
import ContactlessShopping from '@/components/Layout/ContactlessShopping';
import ServicesPage from '@/components/Layout/ServicesPage';
import TrendingBrands from '@/components/Layout/TrendingBrands';
import FeaturedProductGrid from '@/components/Products/FeaturedProductGrid';
import ProductDetails from '@/components/Products/ProductDetails';
import ProductGrid from '@/components/Products/ProductGrid';
import RecentlyViewedItems from '@/components/Products/RecentlyViewedItems';

export default function Home() {
  return (
    <div>
      {/* Hero Slider */}
      <HeroSlider /> 
      <BatteryFinder/>
      {/* Content Section */}
      {/* <div className="space-y-16 px-8 sm:px-20 pb-20"> */}
      <CategoriesType0/>
      <CategoryFeaturedOffers/>
        <AmazingDeals/>
    
        <ContactlessShopping />

        <ServicesPage/>
        <TrendingBrands/>

  
        <FeaturedProductGrid/>
        {/* Product Grid */}
        <ProductGrid />
        
        {/* Contactless Shopping Section */}
      
        {/* Recently Viewed Items */}
        <RecentlyViewedItems />

        <ProductDetails/>

        <CategoryPage/>
        
      {/* </div> */}
    </div>
  );
}
