'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';
import Link from 'next/link';
import {
  ShoppingCartIcon,
  CubeIcon,
  UserGroupIcon,
  TagIcon,
  TruckIcon,
  ArchiveBoxIcon,
  FolderIcon,
} from '@heroicons/react/24/outline';

const AdminDashboard = () => {
  const router = useRouter();
  const [orders, setOrders] = useState<number | undefined>(undefined);
  const [products, setProducts] = useState<number | undefined>(undefined);
  const [customers, setCustomers] = useState<number | undefined>(undefined);
  const [discounts, setDiscounts] = useState<number | undefined>(undefined);
  const [inventoryLevels, setInventoryLevels] = useState<number | undefined>(undefined);
  const [collections, setCollections] = useState<number | undefined>(undefined); // Changed from null to undefined
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    if (!token) {
      router.push('/admin/login');
      return;
    }

    // Fetch data for dashboard widgets
    const fetchData = async () => {
      try {
        const [
          ordersResponse,
          productsResponse,
          customersResponse,
          discountsResponse,
          inventoryResponse,
          collectionsResponse,
        ] = await Promise.all([
          axios.get(`${process.env.NEXT_PUBLIC_API_URL}/orders`),
          axios.get(`${process.env.NEXT_PUBLIC_API_URL}/products`),
          axios.get(`${process.env.NEXT_PUBLIC_API_URL}/customers`),
          axios.get(`${process.env.NEXT_PUBLIC_API_URL}/discounts`),
          axios.get(`${process.env.NEXT_PUBLIC_API_URL}/inventory/levels`),
          axios.get(`${process.env.NEXT_PUBLIC_API_URL}/collections`),
        ]);

        setOrders(ordersResponse.data.orders?.length || 0); // Default to 0 if no orders
        setProducts(productsResponse.data.products?.length || 0);
        setCustomers(customersResponse.data.customers?.length || 0);
        setDiscounts(discountsResponse.data.discounts?.length || 0);
        setInventoryLevels(inventoryResponse.data.inventoryLevels?.length || 0);
        setCollections(collectionsResponse.data.collections?.length || 0); // Default to 0 if no collections
        setLoading(false);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, [router]);

  if (loading) {
    return (
      <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <p className="text-xl text-center">Loading dashboard data...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <h1 className="text-2xl sm:text-3xl font-bold">Admin Dashboard</h1>
      <p className="mt-4 text-sm sm:text-base lg:text-lg">
        Welcome to the admin panel! Manage your shop here.
      </p>

      {/* Dashboard widgets */}
      <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Orders Widget */}
        <DashboardWidget
          title="Orders"
          icon={<ShoppingCartIcon className="w-10 h-10 text-blue-600 mr-4" />}
          dataCount={orders}
          description="Orders"
          link="/admin/orders"
        />

        {/* Products Widget */}
        <DashboardWidget
          title="Products"
          icon={<CubeIcon className="w-10 h-10 text-green-600 mr-4" />}
          dataCount={products}
          description="Products"
          link="/admin/products"
        />

        {/* Customers Widget */}
        <DashboardWidget
          title="Customers"
          icon={<UserGroupIcon className="w-10 h-10 text-purple-600 mr-4" />}
          dataCount={customers}
          description="Customers"
          link="/admin/customers"
        />

        {/* Discounts Widget */}
        <DashboardWidget
          title="Discounts"
          icon={<TagIcon className="w-10 h-10 text-pink-600 mr-4" />}
          dataCount={discounts}
          description="Active Discounts"
          link="/admin/discounts"
        />

        {/* Inventory Widget */}
        <DashboardWidget
          title="Inventory"
          icon={<ArchiveBoxIcon className="w-10 h-10 text-red-600 mr-4" />}
          dataCount={inventoryLevels}
          description="Inventory Levels"
          link="/admin/inventory"
        />

        {/* Shipping Widget */}
        <DashboardWidget
          title="Shipping"
          icon={<TruckIcon className="w-10 h-10 text-yellow-600 mr-4" />}
          description="Check shipping zones and rates"
          link="/admin/shipping"
        />

        {/* Collections Widget */}
        <DashboardWidget
          title="Collections"
          icon={<FolderIcon className="w-10 h-10 text-teal-600 mr-4" />}
          dataCount={collections} // Display collection count
          description="Collections"
          link="/admin/collections"
        />
      </div>
    </div>
  );
};

// Reusable Dashboard Widget Component
const DashboardWidget = ({
  title,
  icon,
  dataCount,
  description,
  link,
}: {
  title: string;
  icon: JSX.Element;
  dataCount?: number; // Making dataCount optional
  description: string;
  link: string;
}) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow flex items-center justify-between">
      <div className="flex items-center">
        {icon}
        <div>
          <h2 className="text-lg font-semibold">{title}</h2>
          {dataCount !== undefined ? (
            <p className="text-gray-600 mt-2">
              {dataCount} {description}
            </p>
          ) : (
            <p className="text-gray-600 mt-2">{description}</p>
          )}
        </div>
      </div>
      <Link href={link} className="text-blue-500 text-sm">
        View
      </Link>
    </div>
  );
};

export default AdminDashboard;
