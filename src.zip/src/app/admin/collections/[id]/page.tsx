'use client';

import CollectionForm from '@/components/Admin/CollectionForm';
// import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Collection } from '@/types/collection'; // Make sure you import your types

interface EditCollectionPageProps {
  params: {
    id: string; // Assuming `id` is a string
  };
}

const EditCollectionPage = ({ params }: EditCollectionPageProps) => {
  // const router = useRouter();
  const collectionId = params?.id;
  const [collection, setCollection] = useState<Collection | undefined>(undefined); // Initialize as undefined

  useEffect(() => {
    if (collectionId) {
      // Ensure you use the correct backend URL here, like a base URL from environment variables
      fetch(`${process.env.NEXT_PUBLIC_API_URL}/collections/${collectionId}`)
        .then(res => res.json())
        .then(data => setCollection(data.collection))
        .catch(err => console.error('Error fetching collection:', err)); // Catch fetch errors
    }
  }, [collectionId]);

  return (
    <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
      {collection ? (
        <CollectionForm collection={collection} />
      ) : (
        <p>Loading collection data...</p>
      )}
    </div>
  );
};

export default EditCollectionPage;
