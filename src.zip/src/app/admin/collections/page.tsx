'use client';

import CollectionList from '@/components/Admin/CollectionList';

const CollectionsPage = () => {
  return (
    <div className="container mx-auto py-6 px-4 sm:px-6 lg:px-8">
      {/* Title */}
      <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold mb-6">Collections</h1>
      
      {/* Collection List */}
      <div className="bg-white rounded-lg shadow-sm p-4 sm:p-6 lg:p-8">
        <CollectionList />
      </div>
    </div>
  );
};

export default CollectionsPage;
