'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { ProductNode } from '@/types/product'; 
import ProductCard from '@/components/Products/ProductCard';  // Reuse the ProductCard component
import BatteryFinder from '@/components/BatteryFinder/BatteryFinder';

const CollectionPage = () => {
  const { collectionLevel1, collectionLevel2 } = useParams();

  const [products, setProducts] = useState<ProductNode[]>([]);

  useEffect(() => {
    if (collectionLevel1 && collectionLevel2) {
      fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/collections/${collectionLevel1}/${collectionLevel2}`
      )
        .then((res) => res.json())
        .then((data) => setProducts(data.products || []))
        .catch((err) => console.error(err));
    }
  }, [collectionLevel1, collectionLevel2]);

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Include BatteryFinder */}
      <BatteryFinder
        preselectedCategory={Array.isArray(collectionLevel1) ? collectionLevel1[0] : collectionLevel1}
        preselectedSubCategory={Array.isArray(collectionLevel2) ? collectionLevel2[0] : collectionLevel2}
      />
      
      <h1 className="text-2xl font-bold text-gray-800 mb-6 text-center capitalize">
        {collectionLevel2 || collectionLevel1}
      </h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.length > 0 ? (
          products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))
        ) : (
          <p className="text-center text-gray-600 col-span-full">No products found</p>
        )}
      </div>
    </div>
  );
};

export default CollectionPage;
