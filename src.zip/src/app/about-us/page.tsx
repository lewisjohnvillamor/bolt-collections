import React from 'react';

const partners = [
  'dyson', 'intel', 'cisco', 'nvidia', 'lenovo', 'bose', 
  'apple', 'google', 'lg', 'sony', 'samsung'
];

const team = [
  { name: 'Thomas Reece', title: 'Co-Founder', img: 'https://via.placeholder.com/150' },
  { name: 'Oscar Byrne', title: 'Co-Founder & Managing Director', img: 'https://via.placeholder.com/150' },
  { name: 'David Evans', title: 'Development Manager', img: 'https://via.placeholder.com/150' },
  { name: 'Jessica Smith', title: 'Customer Service Manager', img: 'https://via.placeholder.com/150' }
];

const boardMembers = [
  { name: 'Judith Winn', title: 'Head of UX Design', img: 'https://via.placeholder.com/150' },
  { name: 'Austin Eldred', title: 'Board Member', img: 'https://via.placeholder.com/150' },
  { name: 'Hayes Joseph', title: 'Former Apple VP', img: 'https://via.placeholder.com/150' },
  { name: 'Kenzie Kraft', title: 'Former Design Head at Uber', img: 'https://via.placeholder.com/150' },
  { name: 'Fred Moon', title: 'Former CTO of Spotify', img: 'https://via.placeholder.com/150' },
  { name: 'Karen Smith', title: 'Former CFO', img: 'https://via.placeholder.com/150' }
];

const AboutUs = () => {
  return (
    <div className="bg-gray-50">
      {/* Intro Section */}
      <section className="text-center px-4 py-16">
        <h1 className="text-4xl font-bold mb-6">We believe that great design should be available to everyone</h1>
        <img src="https://via.placeholder.com/1200x800" alt="About Us Image" className="mx-auto mb-6 w-full rounded-lg shadow-md" />
        <div className="text-left max-w-4xl mx-auto">
          <p className="text-lg mb-4">
            Our Story: We started with a belief that everyone deserves great design, and today, we have become leaders in delivering high-quality design solutions for businesses and individuals alike. Our team is dedicated to creating spaces that are good for people and the planet, offering top-notch service for all your design needs.
          </p>
        </div>
      </section>

      {/* Partners Section */}
      <section className="bg-white py-12">
        <div className="text-center">
          <h2 className="text-3xl font-semibold mb-8">We work with the best partners</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
            {partners.map((partner, index) => (
              <img key={index} src={`https://via.placeholder.com/150x80?text=${partner}`} alt={partner} className="mx-auto" />
            ))}
          </div>
        </div>
      </section>

      {/* How We Work Section */}
      <section className="py-16 bg-gray-100">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-semibold mb-4">We give you the power to create spaces that are just right for you</h2>
          <p className="text-lg">From theme customization to product additions, we offer you complete control over your online store.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
          <div>
            <img src="https://via.placeholder.com/100" alt="Theme Customization" className="mx-auto mb-4" />
            <h3 className="text-xl font-semibold">Choose a Theme</h3>
            <p className="text-gray-600">Customize the look of your shop from our large selection of beautifully designed themes.</p>
          </div>
          <div>
            <img src="https://via.placeholder.com/100" alt="Add Products" className="mx-auto mb-4" />
            <h3 className="text-xl font-semibold">Add Products</h3>
            <p className="text-gray-600">Easily add products and manage inventory, pricing, and details.</p>
          </div>
          <div>
            <img src="https://via.placeholder.com/100" alt="Start Selling" className="mx-auto mb-4" />
            <h3 className="text-xl font-semibold">Start Selling</h3>
            <p className="text-gray-600">Sell to customers worldwide with our seamless integration of payment and shipping.</p>
          </div>
        </div>
      </section>

      {/* Company History Section */}
      <section className="bg-white py-12">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-semibold mb-8">Company History Timeline</h2>
          <ul className="text-left text-lg">
            <li className="mb-4"><strong>2018:</strong> Founded with the goal of making great design accessible to everyone.</li>
            <li className="mb-4"><strong>2019:</strong> Launched our first line of products with resounding success.</li>
            <li className="mb-4"><strong>2020:</strong> Expanded our business globally with customers in over 50 countries.</li>
            <li className="mb-4"><strong>2021:</strong> Raised $100M in Series B funding to scale our operations further.</li>
          </ul>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-gray-100">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-3xl font-semibold mb-12">Here is the team at the helm of the ship</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, idx) => (
              <div key={idx} className="text-center">
                <img src={member.img} alt={member.name} className="w-32 h-32 mx-auto rounded-full mb-4" />
                <h3 className="text-lg font-semibold">{member.name}</h3>
                <p className="text-gray-600">{member.title}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Board Members Section */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-3xl font-semibold mb-12">We’re lucky to be supported by some of the best investors in the world</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {boardMembers.map((member, idx) => (
              <div key={idx} className="text-center">
                <img src={member.img} alt={member.name} className="w-32 h-32 mx-auto rounded-full mb-4" />
                <h3 className="text-lg font-semibold">{member.name}</h3>
                <p className="text-gray-600">{member.title}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gray-100 text-center">
        <h2 className="text-3xl font-semibold mb-4">Purchase the my Battery Plus now and make everything easier</h2>
        <p className="text-lg mb-8">Start your journey today with the most trusted design platform.</p>
        <a href="#" className="bg-black text-white py-3 px-6 rounded-lg hover:bg-gray-800">
          Purchase Theme
        </a>
      </section>
    </div>
  );
};

export default AboutUs;
