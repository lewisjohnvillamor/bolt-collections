import ProductGrid from '@/components/Products/ProductGrid'; // Adjust path as needed

export default function Home() {
  return (
    <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold mb-6">Available Products</h1>
      <ProductGrid /> {/* Render your ProductGrid component */}
    </div>
  );
}
