import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';
import { ProductNode } from '@/types/product';

const ProductDetails = () => {
  const router = useRouter();
  const { slug } = router.query; // Retrieve the product ID/slug from the URL
  const [product, setProduct] = useState<ProductNode | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (slug) {
      // Fetch product data based on slug
      fetch(`${process.env.NEXT_PUBLIC_API_URL}/products/${slug}`)
        .then((res) => res.json())
        .then((data) => setProduct(data.product))
        .catch((err) => console.error(err))
        .finally(() => setLoading(false));
    }
  }, [slug]);

  if (loading) return <p>Loading product details...</p>;
  if (!product) return <p>Product not found</p>;

  // Safely access variants and product images
  const productImage = product.images.edges?.[0]?.node;
  const productVariant = product.variants.edges?.[0]?.node;

  return (
    <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-6">{product.title}</h1>
      {productImage && (
        <img
          src={productImage.originalSrc}
          alt={productImage.altText || product.title}
          className="w-full h-auto mb-4"
        />
      )}
      <p className="text-gray-600">{product.description}</p>
      {productVariant && (
        <p className="text-lg font-bold mt-4">Price: ${productVariant.price}</p>
      )}
    </div>
  );
};

export default ProductDetails;
