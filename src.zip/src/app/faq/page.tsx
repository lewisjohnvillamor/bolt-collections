'use client';
import React, { useState } from 'react';

// Define the structure of FAQ data
interface FaqItem {
  question: string;
  answer: string;
}

interface FaqCategory {
  services: FaqItem[];
  shipping: FaqItem[];
  product: FaqItem[];
}

const faqData: FaqCategory = {
  services: [
    {
      question: "What services does My Battery Plus provide?",
      answer: "My Battery Plus offers a range of services, including roadside battery assistance, battery testing, battery recycling, and battery replacements."
    },
    {
      question: "How do I request roadside battery assistance?",
      answer: "You can request roadside battery assistance by contacting My Battery Plus or visiting our website and using the online request form."
    },
    {
      question: "How long does it take for a technician to arrive?",
      answer: "Response times vary depending on location and traffic conditions. Our technicians aim to reach your location within 30 minutes."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept payment through all major credit cards, as well as online payment services such as PayPal. Payment for battery replacements must be made at the time of service."
    },
    {
      question: "Can you fit a battery to any vehicle?",
      answer: "Yes, our technicians are able to fit batteries for most makes and models of vehicles, provided that it is safe to do so."
    }
  ],
  shipping: [
    {
      question: "How do you calculate shipping costs?",
      answer: "Shipping costs are calculated based on the weight, dimensions, and destination of your order. You can view the estimated shipping cost before placing your order."
    },
    {
      question: "How long does it take for my order to be shipped?",
      answer: "We process and ship orders within 1-3 business days. Shipping times may vary depending on the product’s availability."
    },
    {
      question: "Can I track my order?",
      answer: "Yes, once your order is shipped, you will receive a tracking number via email. You can use this number to monitor your shipment."
    },
    {
      question: "Do you offer international shipping?",
      answer: "Currently, we only ship within Australia. We are exploring options to expand our shipping services to other countries."
    },
    {
      question: "What if I need to change my shipping address?",
      answer: "If you need to change your shipping address after placing an order, please contact us immediately. We cannot guarantee address changes once an order has been processed."
    }
  ],
  product: [
    {
      question: "How do I know if my battery is the issue?",
      answer: "If your car is not starting and there’s a clicking sound when you turn the key, it could be a battery issue. We recommend getting your battery tested at My Battery Plus."
    },
    {
      question: "Do your batteries come with a warranty?",
      answer: "Yes, all of our batteries come with a minimum 2-year warranty. The exact warranty period varies depending on the battery model."
    },
    {
      question: "How do I know which battery is right for my vehicle?",
      answer: "You can use our online battery finder to select the right battery for your vehicle. Simply input your vehicle’s make, model, and year."
    },
    {
      question: "Are your batteries compatible with different makes and models?",
      answer: "Yes, we provide batteries that are compatible with a wide range of makes and models, ensuring that you get the right fit for your vehicle."
    },
    {
      question: "How long should I expect my battery to last?",
      answer: "Battery life varies depending on usage, but most batteries last between 3 to 5 years. Regular maintenance can extend the life of your battery."
    }
  ]
};

const FAQ: React.FC = () => {
  const [servicesOpenIndex, setServicesOpenIndex] = useState<number | null>(null);
  const [shippingOpenIndex, setShippingOpenIndex] = useState<number | null>(null);
  const [productOpenIndex, setProductOpenIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number, type: string) => {
    if (type === "services") {
      setServicesOpenIndex(servicesOpenIndex === index ? null : index);
    } else if (type === "shipping") {
      setShippingOpenIndex(shippingOpenIndex === index ? null : index);
    } else if (type === "product") {
      setProductOpenIndex(productOpenIndex === index ? null : index);
    }
  };

  const renderFAQs = (
    category: string, 
    data: FaqItem[], 
    type: string, 
    openIndex: number | null
  ) => (
    <div className="my-8">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">{category}</h2>
      <div className="divide-y divide-gray-200">
        {data.map((item, index) => (
          <div key={index} className="py-4">
            <div
              className="flex justify-between items-center cursor-pointer"
              onClick={() => toggleAccordion(index, type)}
            >
              <h3 className="text-lg font-semibold">{item.question}</h3>
              <span className={`transition-transform transform ${openIndex === index ? 'rotate-90' : 'rotate-0'}`}>
                {openIndex === index ? '-' : '+'}
              </span>
            </div>
            {openIndex === index && (
              <div className="mt-2 text-gray-600">
                {item.answer}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-center mb-12">FAQ</h1>

      {/* Services */}
      {renderFAQs('Services', faqData.services, "services", servicesOpenIndex)}

      {/* Shipping */}
      {renderFAQs('Shipping', faqData.shipping, "shipping", shippingOpenIndex)}

      {/* Product */}
      {renderFAQs('Product', faqData.product, "product", productOpenIndex)}

      {/* Contact Section */}
      <section className="mt-16 text-center">
        <h2 className="text-2xl font-semibold mb-4">Any questions?</h2>
        <p>If you still haven’t found the answers you’re looking for, feel free to reach out to us and we’ll get back to you as soon as possible.</p>
        <div className="mt-4 flex justify-center space-x-6">
          <div>
            <h3 className="text-lg font-bold">Customer Support</h3>
            <p>Call: (123) 456-7890</p>
          </div>
          <div>
            <h3 className="text-lg font-bold">Email Support</h3>
            <p>Email: support@mybatteryplus.com</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default FAQ;
