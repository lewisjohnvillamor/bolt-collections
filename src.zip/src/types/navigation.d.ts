export interface FeaturedItem {
    name: string;
    href: string;
    imageSrc: string;
    imageAlt: string;
  }
  
  export interface SectionItem {
    name: string;
    href: string;
  }
  
  export interface Section {
    id: string;
    name: string;
    items: SectionItem[];
  }
  
  export interface Category {
    id: string;
    name: string;
    featured: FeaturedItem[];
    sections: Section[];
  }
  
  export interface Page {
    name: string;
    href: string;
  }
  
  export interface Navigation {
    categories: Category[];
    pages: Page[];
  }
  