// eslint-disable-next-line @typescript-eslint/ban-types
declare module 'react-slick' {
  import * as React from 'react';

  interface SliderProps {
    dots?: boolean;
    infinite?: boolean;
    speed?: number;
    slidesToShow?: number;
    slidesToScroll?: number;
    nextArrow?: React.ReactNode;
    prevArrow?: React.ReactNode;
    appendDots?: (dots: React.ReactNode) => React.ReactNode;
    customPaging?: (i: number) => React.ReactNode;
    [key: string]: unknown; // Replace 'any' with 'unknown' for safety
  }

  export default class Slider extends React.Component<SliderProps, Record<string, never>> {}
}
