// src/types/product.d.ts

export interface ProductVariant {
    id: string;
    price: string;  // Price is usually a string in Shopify's API
  }
  
  export interface ProductImage {
    originalSrc: string;
    altText?: string;
  }
  
  export interface ProductNode {
    id: string;
    title: string;
    description: string;
    images: {
      edges: Array<{
        node: ProductImage;
      }>;
    };
    variants: {
      edges: Array<{
        node: ProductVariant;
      }>;
    };
  }
  
  export interface PageInfo {
    hasNextPage: boolean;
    endCursor: string;
  }
  
  export interface ProductsResponse {
    products: {
      edges: Array<{
        cursor: string;
        node: ProductNode;
      }>;
      pageInfo: PageInfo;
    };
  }
  