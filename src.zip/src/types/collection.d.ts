import { ProductNode } from './product'; // Import the ProductNode type

export interface PriceRange {
  min: number;
  max: number;
}

export interface Rules {
  productType?: string;
  vendor?: string;
  tags?: string[];
  priceRange?: PriceRange;
}

export interface Collection {
  _id?: string;
  name: string;
  description: string;
  products: (string | ProductNode)[]; // Array of product IDs or ProductNode
  seoTitle?: string; // Optional SEO title
  seoDescription?: string; // Optional SEO description
  bannerImage?: string; // Optional banner image URL
  isVisible?: boolean; // Flag for visibility
  sortOrder?: number; // Optional sort order
  rules?: Rules; // Optional rules for auto-adding products
}
