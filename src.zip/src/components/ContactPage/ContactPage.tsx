// This ensures the component uses client-side hooks like useState.
'use client';

import React, { useState } from 'react';

// The ContactPage component that runs on the client
const ContactPage: React.FC<{ serverData: string }> = ({ serverData }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission logic here (e.g., send to an API)
    console.log(formData);
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Form Section */}
        <div>
          <h2 className="text-2xl font-bold mb-4">Leave your enquiry here</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <input
                type="text"
                name="name"
                placeholder="Your name"
                value={formData.name}
                onChange={handleChange}
                className="p-3 border rounded w-full"
                required
              />
              <input
                type="email"
                name="email"
                placeholder="Your email"
                value={formData.email}
                onChange={handleChange}
                className="p-3 border rounded w-full"
                required
              />
            </div>
            <input
              type="text"
              name="phone"
              placeholder="Phone Number"
              value={formData.phone}
              onChange={handleChange}
              className="p-3 border rounded w-full"
            />
            <textarea
              name="message"
              rows={4}
              placeholder="Your message"
              value={formData.message}
              onChange={handleChange}
              className="p-3 border rounded w-full"
              required
            />
            <button
              type="submit"
              className="bg-yellow-500 text-white py-3 px-6 rounded hover:bg-yellow-600 transition"
            >
              Send message
            </button>
          </form>
        </div>

        {/* Information Section */}
        <div>
          <h2 className="text-2xl font-bold mb-4"><p>We&apos;re here to help!</p></h2>
          <p className="mb-4">
            At My Battery Plus, we value your feedback and inquiries. We are committed to providing exceptional customer service and ensuring that your experience with our products and services is nothing short of excellent. 
            If you have any questions, concerns, or need assistance, please feel free to reach out to us.
          </p>
          <p className="mb-4">
            You can contact our dedicated customer support team by sending an email to
            <a href="mailto:support@mybatteryplus.com.au" className="text-red-600"> support@mybatteryplus.com.au</a>. 
            Our team will be more than happy to help you with your concerns and provide the information you need.
          </p>
          <p>We aim to try and respond to your enquiries within 24 hours.</p>
          {/* Example of server-side rendered data */}
          <p className="mt-4 text-gray-600">Server Data: {serverData}</p>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
