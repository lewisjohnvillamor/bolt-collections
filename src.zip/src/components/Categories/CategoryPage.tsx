import React from 'react';
import BatteryFinder from '../BatteryFinder/BatteryFinder';
import ProductGrid from '../Products/ProductGrid';


const CategoryPage = () => {
  return (
    <div className="container mx-auto">
      {/* Battery Finder Component */}
      <div className="mt-6">
        <BatteryFinder />
      </div>

      {/* Product Grid Section */}
      <div className="mt-10">
        <ProductGrid />
      </div>
    </div>
  );
};

export default CategoryPage;
