import React from 'react';

const categories = [
  { name: "Cell Phones", imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/homev8-emc01.png?fit=510%2C510&ssl=1" },
  { name: "Laptops", imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/homev8-emc02.png?fit=510%2C510&ssl=1" },
  { name: "TVs & Video", imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/homev8-emc03.png?fit=510%2C510&ssl=1" },
  { name: "Tablets", imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/homev8-emc04.png?fit=510%2C510&ssl=1" },
  { name: "Smart Watches", imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/homev8-emc05.png?fit=510%2C510&ssl=1" },
  { name: "Headphones", imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/homev8-emc06.png?fit=510%2C510&ssl=1" },
];

const CategoriesType0 = () => {
  return (
    <div className="container mx-auto m-2">
        <div>
  {/* For larger screens (md and above) - keep "Explore More Categories" at the top */}
  <div className="flex justify-between items-center mb-6 hidden sm:flex">
    <h2 className="text-2xl m-2 font-semibold">Explore More Categories</h2>
    <a href="#" className="text-sm m-2 text-blue-600 hover:underline">
      See All Categories
    </a>
  </div>

  {/* For mobile devices (sm and below) - move "Explore More Categories" to the bottom of the header */}
  <div className="flex flex-col items-center sm:hidden mt-6">
    <h2 className="text-2xl m-2 font-semibold">Explore More Categories</h2>
    <a href="#" className="text-sm m-2 text-blue-600 hover:underline">
      See All Categories
    </a>
  </div>
</div>
      {/* Use flexbox to control spacing */}
      <div className="flex flex-wrap justify-center lg:justify-between gap-4 m-1">
        {categories.map((category, idx) => (
          <div
            key={idx}
            className="flex flex-col items-center justify-center h-64 w-32 lg:w-40 bg-gray-100 rounded-lg hover:bg-white hover:shadow-lg transition-all duration-300"
          >
            <img
              src={category.imgSrc}
              alt={category.name}
              className="h-24 mb-3 object-contain"
            />
            <p className="text-lg font-semibold">{category.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoriesType0;
