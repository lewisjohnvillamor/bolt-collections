import React from 'react';

const featuredOffers = [
  {
    name: "Xbox Cyber Week Sale",
    description: "Save up to 50% on select Xbox games",
    // discount: "50% OFF",
    imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2023/03/homev10-xbox.jpg?fit=728%2C400&ssl=1", // Replace with a real image link
    discountBg: "bg-purple-500",
  },
  {
    name: "Samsung Galaxy SmartTag+",
    description: "Save up to 25% off. Limited time only.",
    // discount: "25% OFF",
    imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2023/03/homev10-smarttag.jpg?fit=728%2C400&ssl=1", // Replace with a real image link
    discountBg: "bg-red-500",
  },
  {
    name: "Work From Anywhere Bundle",
    description: "Up to 30% off PC Accessories",
    // discount: "30% OFF",
    imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2023/03/homev10-workfrom.jpg?fit=728%2C400&ssl=1", // Replace with a real image link
    discountBg: "bg-blue-500",
  },
];

const CategoryFeaturedOffers = () => {
  return (
    <div className="container mx-auto p-2">
            <div>
            {/* For larger screens (md and above) - keep "Our Featured Offers" at the top */}
            <div className="flex justify-between items-center mb-6 hidden sm:flex">
                <h2 className="text-2xl font-semibold">Our Featured Offers</h2>
                <a href="#" className="text-sm text-blue-600 hover:underline">
                See All
                </a>
            </div>

            {/* For mobile devices (sm and below) - move "Our Featured Offers" to the bottom */}
            <div className="flex flex-col items-center sm:hidden mt-6">
                <h2 className="text-2xl font-semibold">Our Featured Offers</h2>
                <a href="#" className="text-sm text-blue-600 hover:underline">
                See All
                </a>
            </div>
            </div>


      {/* Offers */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {featuredOffers.map((offer, idx) => (
          <div
            key={idx}
            className="relative rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300"
          >
            <img
              src={offer.imgSrc}
              alt={offer.name}
              className="w-full h-64 object-cover"
            />

            {/* Discount badge */}
            {/* <div
              className={`absolute top-4 left-4 text-white px-3 py-1 text-xs rounded-full ${offer.discountBg}`}
            >
              {offer.discount}
            </div> */}

            {/* Offer details */}
            <div className="p-4">
              <h3 className="font-semibold text-lg">{offer.name}</h3>
              <p className="text-sm text-gray-600">{offer.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoryFeaturedOffers;
