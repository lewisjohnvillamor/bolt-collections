"use client";

import React, { useState, useEffect } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination, Navigation } from 'swiper/modules'; // Import both modules
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

const slides = [
  {
    title: 'All Systems Pro.',
    description: 'The Apple M1 chip gives the 13 inch MacBook Pro speed and power beyond belief.',
    image: 'https://motta.uix.store/electronic/wp-content/uploads/sites/6/2022/09/homev6-slider-01.jpg',
    backgroundColor: 'bg-black',
    textColor: 'text-white',
    buttonText: 'Buy Now',
    linkText: 'Learn More',
  },
  {
    title: 'One For All',
    description: 'No wires. A world of experiences. Unlike anything you\'ve ever seen.',
    image: 'https://motta.uix.store/electronic/wp-content/uploads/sites/6/2022/09/homev6-slider2.jpg',
    backgroundColor: 'bg-gray-200',
    textColor: 'text-black',
    buttonText: 'Buy Now',
    linkText: 'Learn More',
  },
  {
    title: 'For The Gamer',
    description: 'Wrap up next-level tech for Gamers.',
    image: 'https://motta.uix.store/electronic/wp-content/uploads/sites/6/2022/09/homev6-slider3.jpg',
    backgroundColor: 'bg-gray-100',
    textColor: 'text-black',
    buttonText: 'Buy Now',
    linkText: 'Learn More',
  },
];

const HeroSlider = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isMobile, setIsMobile] = useState(false); // Track screen size

  // Function to handle screen size change
  const handleResize = () => {
    setIsMobile(window.innerWidth <= 768); // Check if the screen width is <= 768px
  };

  // Add event listener on component mount and clean up on unmount
  useEffect(() => {
    handleResize(); // Call initially
    window.addEventListener('resize', handleResize); // Add event listener
    return () => window.removeEventListener('resize', handleResize); // Clean up
  }, []);

  return (
    <div className={`w-full ${slides[activeIndex].backgroundColor} transition-all duration-500`}>
      <div className="container mx-auto">
        <Swiper
          modules={isMobile ? [Pagination] : [Navigation, Pagination]} // Conditionally load modules
          spaceBetween={50}
          slidesPerView={1}
          pagination={{ clickable: true }}
          navigation={!isMobile} // Conditionally enable navigation
          onSlideChange={(swiper) => setActiveIndex(swiper.activeIndex)}
        >
          {slides.map((slide, idx) => (
            <SwiperSlide key={idx}>
              <div className="relative">
                <div className="max-w-screen-xl mx-auto flex flex-col-reverse md:flex-row justify-between items-center h-full w-full px-4 py-10">
                  {/* Text Section */}
                  <div className="space-y-5 md:w-1/2">
                    <h1 className={`text-4xl md:text-5xl font-bold ${slide.textColor}`}>
                      {slide.title}
                    </h1>
                    <p className={`text-lg ${slide.textColor}`}>
                      {slide.description}
                    </p>
                    <div className="flex space-x-4">
                      <button className="px-6 py-3 bg-green-500 text-white rounded-full hover:bg-green-600">
                        {slide.buttonText}
                      </button>
                      <a href="#" className={`px-6 py-3 underline ${slide.textColor}`}>
                        {slide.linkText}
                      </a>
                    </div>
                  </div>

                  {/* Image Section */}
                  <div className="md:w-1/2">
                    <img
                      src={slide.image}
                      alt={slide.title}
                      className="w-full h-auto object-contain"
                    />
                  </div>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
};

export default HeroSlider;
