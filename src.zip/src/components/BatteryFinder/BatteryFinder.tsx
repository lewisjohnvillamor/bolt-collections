'use client';
import { useState, useEffect } from 'react';
import { FaSearch } from 'react-icons/fa';
import axios from 'axios';
import { useRouter } from 'next/navigation';

interface BatteryFinderProps {
  preselectedCategory?: string;
  preselectedSubCategory?: string;
  preselectedWithinSubCategory?: string;
}

const BatteryFinder = ({ preselectedCategory, preselectedSubCategory, preselectedWithinSubCategory }: BatteryFinderProps) => {
  const router = useRouter();

  const [categories, setCategories] = useState<string[]>([]);
  const [subCategories, setSubCategories] = useState<string[]>([]);
  const [withinSubCategories, setWithinSubCategories] = useState<string[]>([]);

  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>('');
  const [selectedWithinSubCategory, setSelectedWithinSubCategory] = useState<string>('');

  const [isLoadingCategories, setIsLoadingCategories] = useState(true);
  const [isLoadingSubCategories, setIsLoadingSubCategories] = useState(false);
  const [isLoadingWithinSubCategories, setIsLoadingWithinSubCategories] = useState(false); // Will use it now

  const BASE_URL = 'https://mybatterplus-backend-system-76e0bacf3b4c.herokuapp.com/api/batteryfinder';

  const formatUrlToText = (value: string | undefined) => value?.replace(/-/g, ' ') || '';

  // Fetch categories (Level 1) and preselect if needed
  useEffect(() => {
    const fetchCategories = async () => {
      setIsLoadingCategories(true);
      try {
        const response = await axios.get(`${BASE_URL}/categories`);
        setCategories(response.data?.data || []);

        if (preselectedCategory) {
          const formattedCategory = formatUrlToText(preselectedCategory);
          setSelectedCategory(formattedCategory);
        }
      } catch (error) {
        console.error('Error fetching categories:', error);
      } finally {
        setIsLoadingCategories(false);
      }
    };
    fetchCategories();
  }, [preselectedCategory]);

  // Fetch sub-categories (Level 2) after category is selected or preselected
  useEffect(() => {
    if (selectedCategory) {
      const fetchSubCategories = async () => {
        setIsLoadingSubCategories(true);
        try {
          const response = await axios.get(`${BASE_URL}/categories/${selectedCategory}/subcategories`);
          setSubCategories(response.data?.data || []);

          if (preselectedSubCategory) {
            const formattedSubCategory = formatUrlToText(preselectedSubCategory);
            setSelectedSubCategory(formattedSubCategory);
          }
        } catch (error) {
          console.error('Error fetching sub-categories:', error);
        } finally {
          setIsLoadingSubCategories(false);
        }
      };
      fetchSubCategories();
    } else {
      setSubCategories([]);
    }
  }, [selectedCategory, preselectedSubCategory]);

  // Fetch within sub-categories (Level 3) after sub-category is selected or preselected
  useEffect(() => {
    if (selectedCategory && selectedSubCategory) {
      const fetchWithinSubCategories = async () => {
        setIsLoadingWithinSubCategories(true); // Set loading to true while fetching within sub-categories
        try {
          const response = await axios.get(
            `${BASE_URL}/categories/${selectedCategory}/subcategories/${selectedSubCategory}/withinsubcategories`
          );
          setWithinSubCategories(response.data?.data || []);

          if (preselectedWithinSubCategory) {
            const formattedWithinSubCategory = formatUrlToText(preselectedWithinSubCategory);
            setSelectedWithinSubCategory(formattedWithinSubCategory);
          }
        } catch (error) {
          console.error('Error fetching within sub-categories:', error);
        } finally {
          setIsLoadingWithinSubCategories(false); // Set loading to false after fetching is complete
        }
      };
      fetchWithinSubCategories();
    } else {
      setWithinSubCategories([]);
    }
  }, [selectedCategory, selectedSubCategory, preselectedWithinSubCategory]);

  // Handler for the search button
  const handleSearch = () => {
    if (selectedCategory) {
      const categoryPath = [selectedCategory, selectedSubCategory, selectedWithinSubCategory]
        .filter((item) => item)
        .map((item) => item.replace(/\s+/g, '-'))  // Replace spaces with dashes for the URL
        .join('/');
      router.push(`collections/${categoryPath}`);
    }
  };

  return (
    <div className="bg-black p-4 text-white mt-0 mb-0">
      <div className="container mx-auto text-center md:text-center">
        <div className="flex flex-col md:flex-row justify-center items-center gap-4">
          {/* Category Dropdown */}
          <select
            className="bg-white text-black p-2 rounded-md w-full md:w-48"
            value={selectedCategory}
            onChange={(e) => {
              setSelectedCategory(e.target.value);
              setSelectedSubCategory('');
              setSelectedWithinSubCategory('');
            }}
            disabled={isLoadingCategories}
          >
            <option value="">{isLoadingCategories ? 'Loading Categories...' : 'Category'}</option>
            {categories.map((category, idx) => (
              <option key={idx} value={category}>
                {category}
              </option>
            ))}
          </select>

          {/* Sub-category Dropdown */}
          <select
            className="bg-white text-black p-2 rounded-md w-full md:w-48"
            value={selectedSubCategory}
            onChange={(e) => {
              setSelectedSubCategory(e.target.value);
              setSelectedWithinSubCategory('');
            }}
            disabled={isLoadingSubCategories || subCategories.length === 0}
          >
            <option value="">{isLoadingSubCategories ? 'Loading Sub-categories...' : 'Sub Category'}</option>
            {subCategories.map((subCategory, idx) => (
              <option key={idx} value={subCategory}>
                {subCategory}
              </option>
            ))}
          </select>

          {/* Within Sub-category Dropdown */}
          <select
            className="bg-white text-black p-2 rounded-md w-full md:w-48"
            value={selectedWithinSubCategory}
            onChange={(e) => setSelectedWithinSubCategory(e.target.value)}
            disabled={isLoadingWithinSubCategories || withinSubCategories.length === 0} // Use the loading state here
          >
            <option value="">{isLoadingWithinSubCategories ? 'Loading Within Sub-categories...' : 'Within Sub-category'}</option>
            {withinSubCategories.map((withinSubCategory, idx) => (
              <option key={idx} value={withinSubCategory}>
                {withinSubCategory}
              </option>
            ))}
          </select>

          {/* Search Button */}
          <button
            onClick={handleSearch}
            className="bg-yellow-500 text-black p-3 rounded-full hover:bg-yellow-600 transition-all"
            disabled={isLoadingCategories || isLoadingSubCategories || isLoadingWithinSubCategories}  // Disable while loading
          >
            <FaSearch size={18} />
          </button>
        </div>

        <h1 className="text-xs mt-2 font-bold">
          BATTERY FINDER <span className="text-red-500">Powered by AutoFlowSolutions</span>
        </h1>
      </div>
    </div>
  );
};

export default BatteryFinder;
