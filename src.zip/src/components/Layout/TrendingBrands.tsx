import React from 'react';

const brands = [
  { name: 'Dyson', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/home8-dyson.png?fit=510%2C240&ssl=1' },
  { name: 'Lenovo', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2023/03/home8-lenovo.png?fit=510%2C240&ssl=1' },
  { name: 'Cisco', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/home8-cisco.png?fit=510%2C240&ssl=1' },
  { name: 'Samsung', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2023/03/home8-samsung.png?fit=510%2C240&ssl=1' },
  { name: 'LG', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2023/03/home8-lg.png?fit=510%2C240&ssl=1' },
  { name: 'Bose', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/home8-bose.png?fit=510%2C240&ssl=1' },
  { name: 'Apple', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2023/03/home8-apple.png?fit=510%2C240&ssl=1' },
  { name: 'Google', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/home8-google.png?fit=510%2C240&ssl=1' },
  { name: 'Nvidia', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/home8-nvidia.png?fit=510%2C240&ssl=1' },
  { name: 'Electrolux', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/11/home8-electrolux.png?fit=510%2C240&ssl=1' },
  { name: 'Sony', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2023/03/home8-sony.png?fit=510%2C240&ssl=1' },
  { name: 'Intel', imgSrc: 'https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2023/03/home8-intel.png?fit=510%2C240&ssl=1' },
];

const TrendingBrands = () => {
  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold">Trending Brands</h2>
        <a href="#" className="text-sm text-blue-600 hover:underline">
          See All Brands
        </a>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-8 items-center">
        {brands.map((brand, idx) => (
          <div key={idx} className="flex justify-center">
            <img src={brand.imgSrc} alt={brand.name} className="h-12 object-contain" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default TrendingBrands;
