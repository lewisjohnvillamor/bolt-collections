import { Menu, Transition } from '@headlessui/react';
import { Fragment } from 'react';

const MegaMenu = () => {
  return (
    <Menu as="div" className="relative">
      <Menu.Button className="hover:underline cursor-pointer text-black">
        Shop
      </Menu.Button>
      <Transition
        as={Fragment}
        enter="transition ease-out duration-100"
        enterFrom="transform opacity-0 scale-95"
        enterTo="transform opacity-100 scale-100"
        leave="transition ease-in duration-75"
        leaveFrom="transform opacity-100 scale-100"
        leaveTo="transform opacity-0 scale-95"
      >
        <Menu.Items className="absolute left-0 w-screen top-full bg-white shadow-lg z-20">
          <div className="grid grid-cols-4 gap-6 p-6 container mx-auto">
            <div>
              <h4 className="font-bold mb-3">Shop</h4>
              <ul>
                <li><a href="#" className="block py-2 hover:underline">Shop v1</a></li>
                <li><a href="#" className="block py-2 hover:underline">Shop v2</a></li>
              </ul>
            </div>
            {/* Additional columns */}
          </div>
        </Menu.Items>
      </Transition>
    </Menu>
  );
};

export default MegaMenu;
