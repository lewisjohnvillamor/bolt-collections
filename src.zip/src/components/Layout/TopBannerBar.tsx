import React from 'react';
import { FaTruck, FaShieldAlt, FaShoppingBag, FaUndo } from 'react-icons/fa'; // Import necessary icons from Font Awesome

const TopBannerBar: React.FC = () => {
  return (
    <div className="bg-blue-100 text-blue-900 p-2 text-xs sm:text-sm border-t-4 border-green-600">
      <div className="container mx-auto">
        {/* Show only the first item on mobile */}
        <div className="flex items-center space-x-2 sm:hidden">
          <FaTruck className="text-blue-900" />
          <span>Free shipping on orders over $50</span>
        </div>

        {/* Show the full banner on larger screens */}
        <div className="hidden sm:flex flex-col sm:flex-row justify-center items-center space-y-2 sm:space-y-0 sm:space-x-8">
          <div className="flex items-center space-x-2">
            <FaTruck className="text-blue-900" />
            <span>Free shipping on orders over $50</span>
          </div>
          <div className="flex items-center space-x-2">
            <FaShieldAlt className="text-blue-900" />
            <span>30 days money back guarantee</span>
          </div>
          <div className="flex items-center space-x-2">
            <FaShoppingBag className="text-blue-900" />
            <span>Next day delivery free—spend over $99</span>
          </div>
          <div className="flex items-center space-x-2">
            <FaUndo className="text-blue-900" />
            <span>60-Day free returns, All shipping methods</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopBannerBar;
