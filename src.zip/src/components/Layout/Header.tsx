"use client"; // Ensure the component is client-side

import React, { useState } from "react";
import { FaUser, FaShoppingCart, FaHeart, FaBars, FaTimes } from "react-icons/fa";
import { slide as BurgerMenu } from "react-burger-menu";
import SearchForm from "./SearchForm";
import TopBannerBar from "./TopBannerBar";
import { useScreen } from "@/context/ScreenContext"; // Importing useScreen

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  // Use the useScreen hook to get screen size
  const { isMobile, isTablet, isDesktop } = useScreen();

  // Handler for closing the burger menu when clicking a link
  const handleMenuStateChange = (state: { isOpen: boolean }) => {
    setIsOpen(state.isOpen);
  };

  // Early return if mobile view
  if (isMobile) {
    return (
      <>
        <TopBannerBar />
        <header className="bg-[#000000] text-white py-4 shadow-md">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center">
              {/* Burger Menu Icon */}
              <FaBars className="text-white text-2xl" onClick={() => setIsOpen(true)} />

              {/* Centered Logo */}
              <a href="/" className="flex-grow text-center">
                <img
                  src="https://mybatteryplus.com.au/cdn/shop/files/logo_185x@2x.png?v=1647340651"
                  alt="My Battery Plus Logo"
                  className="h-10 sm:h-12 mx-auto"
                />
              </a>

              {/* Icons on Right */}
              <div className="flex space-x-2">
                <a href="#" className="p-2 w-8 h-8 flex justify-center items-center border border-gray-200 rounded-md">
                  <FaUser className="text-sm" />
                </a>
                <a href="#" className="p-2 w-8 h-8 flex justify-center items-center bg-red-500 text-white rounded-md">
                  <FaShoppingCart className="text-sm" />
                  <span className="bg-white text-red-500 rounded-full px-1 py-0.5 text-xs ml-1">4</span>
                </a>
              </div>
            </div>

            {/* Search Bar */}
            <div className="mt-4 flex justify-center">
              <div className="w-full max-w-sm">
                <SearchForm />
              </div>
            </div>
          </div>

          {/* Burger Menu */}
          <BurgerMenu
            right
            isOpen={isOpen}
            onStateChange={handleMenuStateChange}
            customCrossIcon={<FaTimes className="w-6 h-6 text-gray-700" />}
            styles={{
              bmBurgerButton: { display: 'none' },
              bmMenuWrap: { position: "fixed", height: "100%" },
              bmMenu: { background: "#fff", padding: "2.5em 1.5em", fontSize: "1.15em" },
              bmItemList: { color: "#373a47", padding: "0.8em" },
              bmOverlay: { background: "rgba(0, 0, 0, 0.3)" },
            }}
          >
            <a href="/" className="text-black block py-2 hover:underline">Home</a>
            <a href="/category1" className="text-black block py-2 hover:underline">Category 1</a>
            <a href="/category2" className="text-black block py-2 hover:underline">Category 2</a>
            <a href="/category3" className="text-black block py-2 hover:underline">Category 3</a>
            <a href="/faq" className="text-black block py-2 hover:underline">FAQ</a>
            <a href="/contact" className="text-black block py-2 hover:underline">Contact Us</a>
            <a href="/blogs" className="text-black block py-2 hover:underline">Blog</a>
          </BurgerMenu>
        </header>
      </>
    );
  }

  // Return tablet or desktop layout
  return (
    <>
      <TopBannerBar />
      <header className="bg-[#000000] text-white py-4 shadow-md">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            {/* Logo */}
            <a href="/" className="flex items-center">
              <img
                src="https://mybatteryplus.com.au/cdn/shop/files/logo_185x@2x.png?v=1647340651"
                alt="My Battery Plus Logo"
                className="h-10 sm:h-12 w-auto"
              />
            </a>

            {/* Search Bar */}
            <div className="flex-grow mx-6 max-w-md">
              <SearchForm />
            </div>

            {/* Account, Wishlist, Cart Icons */}
            <div className="flex items-center space-x-4">
              <a href="#" className="flex items-center justify-center border border-gray-200 rounded-lg p-2 w-10 h-10">
                <FaUser className="text-lg" />
              </a>
              <a href="#" className="flex items-center justify-center border border-gray-200 rounded-lg p-2 w-10 h-10">
                <FaHeart className="text-lg" />
              </a>
              <a href="#" className="flex items-center justify-center bg-red-500 text-white px-4 py-2 rounded-lg">
                <FaShoppingCart className="text-lg" />
                <span className="hidden sm:inline text-sm ml-2">Cart</span>
                <span className="bg-white text-red-500 rounded-full px-2 py-1 text-xs ml-2">4</span>
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Full Navigation Bar (visible in desktop and tablet view) */}
      {(isDesktop || isTablet) && (
        <nav className="bg-white py-4 shadow-md">
          <div className="container mx-auto flex justify-between items-center">
            <div className="flex space-x-6">
              <a href="/" className="text-black hover:underline">Home</a>
              <a href="/category1" className="text-black hover:underline">Category 1</a>
              <a href="/category2" className="text-black hover:underline">Category 2</a>
              <a href="/category3" className="text-black hover:underline">Category 3</a>
              <a href="/faq" className="text-black hover:underline">FAQ</a>
              <a href="/contact" className="text-black hover:underline">Contact Us</a>
              <a href="/blogs" className="text-black hover:underline">Blog</a>
            </div>
          </div>
        </nav>
      )}
    </>
  );
};

export default Header;
