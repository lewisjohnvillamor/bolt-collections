import React from 'react';

const ContactlessShopping = () => {
  return (
    <div className="container mx-auto p-2 ">
      <h2 className="text-2xl font-bold mb-6">Contactless Shopping Options</h2>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* First Card */}
        <div className="bg-purple-100 p-6 rounded-lg flex justify-between items-center">
          <div className="flex flex-col">
            <h3 className="text-lg font-semibold ">
              Earn Cash Back For The Things
            </h3>
            <h3 className="text-lg font-semibold mb-3">
            You Buy Everywhere
            </h3>
            <div className="flex items-center mb-2">
              <button className="bg-purple-600 text-white px-4 py-2 rounded-md mr-4">
                Apply Now
              </button>
              <a href="#" className="text-purple-600 hover:underline">
                Learn More
              </a>
            </div>
            <p className="text-xs text-gray-600">
              Application via Motta. <a href="#" className="underline">See Terms & Conditions.</a>
            </p>
          </div>
          <img
            src="https://motta.uix.store/electronic/wp-content/uploads/sites/6/2022/09/homev6-cashback.png"
            alt="Card Icon"
            className="w-54"
          />
        </div>

        {/* Second Card with background image */}
        <div
          className="relative bg-cover bg-center p-6 rounded-lg flex flex-col justify-between"
          style={{
            backgroundImage:
              'url(https://motta.uix.store/electronic/wp-content/uploads/sites/6/2023/03/homev6-app-bg.jpg)',
          }}
        >
          <div className="absolute inset-0 bg-opacity-50"></div>
          <div>
            <h3 className="text-lg font-semibold relative mt-8 z-10">
              Simplify Your Shopping
            </h3>
            <h3 className="text-lg font-semibold mb-3 relative z-10">
               With the App
            </h3>
            <p className="text-sm text-gray-700 mb-4 relative z-10">
              Shopping on the go is fast and easy with our free app.
            </p>
            <div className="flex space-x-4 relative z-10">
              <a href="#">
                <img
                  src="https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/09/appstore.png?fit=108%2C32&ssl=1"
                  alt="App Store"
                  className="w-24"
                />
              </a>
              <a href="#">
                <img
                  src="https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/09/ggstore.png?fit=108%2C32&ssl=1"
                  alt="Google Play"
                  className="w-24"
                />
              </a>
            </div>
          </div>
        
        </div>
      </div>
    </div>
  );
};

export default ContactlessShopping;
