import React from 'react';
import { FaSearch } from 'react-icons/fa'; // Importing the search icon

const SearchForm: React.FC = () => {
  return (
    <form className="flex w-full sm:max-w-lg relative mx-2 sm:mx-0" method="get" action="https://motta.uix.store/electronic/">
      <div className="flex-grow relative">
        <input 
          type="text" 
          name="s" 
          className="w-full px-4 py-2 rounded-l-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" 
          placeholder="Search for anything" 
          autoComplete="off" 
        />
        
        {/* Dropdown for Trending Searches */}
        <div className="absolute top-full left-0 w-full bg-white shadow-lg z-10 p-2 mt-2 hidden">
          <div className="font-semibold text-gray-500 mb-2">Trending Searches</div>
          <ul className="space-y-1 text-sm">
            <li><a href="https://motta.uix.store/electronic/flash-deals/" className="text-blue-500 hover:underline">Daily Deals</a></li>
            <li><a href="https://motta.uix.store/electronic/product-category/ipads-tablets/ipad/" className="text-blue-500 hover:underline">iPad</a></li>
            <li><a href="https://motta.uix.store/electronic/product-category/cell-phones/" className="text-blue-500 hover:underline">Cell Phones</a></li>
          </ul>
        </div>
      </div>
      
      {/* Search Button */}
      <button 
        type="submit" 
        className="bg-blue-500 text-white px-4 py-2 rounded-r-full flex items-center justify-center hover:bg-blue-600 transition duration-300" 
        aria-label="Search"
      >
        <FaSearch className="w-5 h-5" /> {/* Ensure icon is visible */}
      </button>

      <input type="hidden" name="post_type" value="product" />
    </form>
  );
};

export default SearchForm;
