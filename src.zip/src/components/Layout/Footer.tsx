"use client";
import React from "react";
import { FaGlobe, FaShieldAlt, FaUndoAlt, FaHeadset } from "react-icons/fa";
import { FaTwitter, FaFacebook, FaYoutube, FaInstagram, FaWhatsapp } from "react-icons/fa";

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t py-8">
      {/* Top section for services */}
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8 text-center md:text-left">
        <div className="space-y-2">
          <FaGlobe className="text-4xl mx-auto md:mx-0 text-gray-700" />
          <h3 className="font-semibold">Worldwide Delivery</h3>
          <p className="text-sm text-gray-500">200 countries and regions worldwide</p>
        </div>
        <div className="space-y-2">
          <FaShieldAlt className="text-4xl mx-auto md:mx-0 text-gray-700" />
          <h3 className="font-semibold">Secure Payment</h3>
          <p className="text-sm text-gray-500">Pay with popular and secure payment methods</p>
        </div>
        <div className="space-y-2">
          <FaUndoAlt className="text-4xl mx-auto md:mx-0 text-gray-700" />
          <h3 className="font-semibold">60-day Return Policy</h3>
          <p className="text-sm text-gray-500">Merchandise must be returned within 60 days</p>
        </div>
        <div className="space-y-2">
          <FaHeadset className="text-4xl mx-auto md:mx-0 text-gray-700" />
          <h3 className="font-semibold">24/7 Help Center</h3>
          <p className="text-sm text-gray-500">We&apos;ll respond to you within 24 hours</p>
        </div>
      </div>

      {/* Divider */}
      <div className="border-t my-8"></div>

      {/* Bottom section for links and newsletter */}
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-5 gap-8">
        {/* Navigation Links */}
        <div>
          <h4 className="font-semibold mb-4">Get to Know Us</h4>
          <ul className="space-y-2 text-sm text-gray-500">
            <li><a href="#">About Us</a></li>
            <li><a href="#">News & Blog</a></li>
            <li><a href="#">Careers</a></li>
            <li><a href="#">Investors</a></li>
            <li><a href="#">Contact Us</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-4">Customer Service</h4>
          <ul className="space-y-2 text-sm text-gray-500">
            <li><a href="#">Help Center</a></li>
            <li><a href="#">FAQs</a></li>
            <li><a href="#">Accessibility</a></li>
            <li><a href="#">Feedback</a></li>
            <li><a href="#">Size Guide</a></li>
            <li><a href="#">Payment Method</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-4">Orders & Returns</h4>
          <ul className="space-y-2 text-sm text-gray-500">
            <li><a href="#">Track Order</a></li>
            <li><a href="#">Shipping & Delivery</a></li>
            <li><a href="#">Return & Exchange</a></li>
            <li><a href="#">Price Match Guarantee</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-4">Legal</h4>
          <ul className="space-y-2 text-sm text-gray-500">
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms of Use</a></li>
            <li><a href="#">Legal</a></li>
            <li><a href="#">Site Map</a></li>
          </ul>
        </div>

        {/* Newsletter and Socials */}
        <div className="md:col-span-1">
          <h4 className="font-semibold mb-4"><p>Let&apos;s keep in touch</p></h4>
          <p className="text-sm text-gray-500 mb-4">
            Get recommendations, tips, updates, and more.
          </p>
          <div className="flex space-x-2 mb-4">
            <input
              type="email"
              className="w-full p-2 border border-gray-300 rounded"
              placeholder="Enter your email address"
            />
            <button className="bg-green-500 text-white px-4 py-2 rounded">
              Subscribe
            </button>
          </div>
          <div className="flex space-x-4 text-2xl justify-center md:justify-start">
            <a href="#"><FaTwitter /></a>
            <a href="#"><FaFacebook /></a>
            <a href="#"><FaYoutube /></a>
            <a href="#"><FaInstagram /></a>
            <a href="#"><FaWhatsapp /></a>
          </div>
        </div>
      </div>

      {/* Social Icons & Payment Methods */}
      <div className="container mx-auto px-4 mt-8 flex flex-col md:flex-row items-center justify-between text-center md:text-left">
              {/* Copyright Text */}
              
        <p>Copyright © 2024 My Battery Plus, All rights reserved.</p>

        {/* Payment Method Icons */}
        <div className=" md:mt-0 space-x-4 flex justify-center md:justify-end">
          <img
            src="https://motta.uix.store/wp-content/uploads/2021/12/footer-bank-transfer.png"
            alt="Bank Transfer"
            className="h-4"
          />
          <img
            src="https://motta.uix.store/wp-content/uploads/2021/12/footer-visa.png"
            alt="Visa"
            className="h-4"
          />
          <img
            src="https://motta.uix.store/wp-content/uploads/2021/12/footer-mastercard.png"
            alt="Mastercard"
            className="h-4"
          />
          <img
            src="https://motta.uix.store/wp-content/uploads/2021/12/footer-paypal.png"
            alt="PayPal"
            className="h-4"
          />
        </div>
      </div>


     
    </footer>
  );
};

export default Footer;
