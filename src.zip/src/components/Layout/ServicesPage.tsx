import React from 'react';

const services = [
  {
    title: "Tire fitting",
    description: "Pair text with an image to focus on your chosen product, collection, or blog post. Add details on availability, style, or even provide a review.",
    imgSrc: "https://maranello-theme.myshopify.com/cdn/shop/files/banner_fitting.jpg?v=1670522769&width=1100",
    link: "#",
  },
  {
    title: "Mobile tire fitting",
    description: "Pair text with an image to focus on your chosen product, collection, or blog post. Add details on availability, style, or even provide a review.",
    imgSrc: "https://maranello-theme.myshopify.com/cdn/shop/files/banner_mobile.jpg?v=1670523021&width=1100",
    link: "#",
  },
  {
    title: "Tire balance & alignment",
    description: "Pair text with an image to focus on your chosen product, collection, or blog post. Add details on availability, style, or even provide a review.",
    imgSrc: "https://maranello-theme.myshopify.com/cdn/shop/files/banner_alignment.jpg?v=1670523177&width=1100",
    link: "#",
  },
];

const ServicesPage = () => {
  return (
    <div className="container mx-auto p-4">
      <h2 className="text-3xl font-bold mb-6">Our Services</h2>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((service, idx) => (
          <div key={idx} className="rounded-lg shadow-lg bg-white overflow-hidden">
            <img src={service.imgSrc} alt={service.title} className="w-full h-64 object-cover" />
            <div className="p-4">
              <h3 className="text-lg font-semibold mb-2">{service.title}</h3>
              <p className="text-sm text-gray-600 mb-4">{service.description}</p>
              <a href={service.link} className="text-red-600 hover:underline">
                Learn more
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServicesPage;
