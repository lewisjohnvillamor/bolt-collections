'use client';

import { slide as BurgerMenu } from 'react-burger-menu'; // Correctly import the slide menu from react-burger-menu
import { useState } from 'react';
import { FaBars, FaTimes } from 'react-icons/fa'; // Import FontAwesome icons for burger menu

const NavigationBar = () => {
  const [isOpen, setIsOpen] = useState(false);

  // Handler for closing the burger menu when clicking a link
  const handleMenuStateChange = (state: { isOpen: boolean }) => {
    setIsOpen(state.isOpen);
  };

  return (
    <nav className="bg-white py-4 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        
        {/* Left side nav items - shown only on larger screens */}
        <div className="hidden md:flex space-x-6">
          <a href="/" className="text-black hover:underline">Home</a>
          <div className="relative group">
            <button className="text-black hover:underline">Categories</button>
            <div className="absolute hidden group-hover:block bg-white shadow-lg rounded-lg mt-1 z-10">
              <a href="/category1" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Category 1</a>
              <a href="/category2" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Category 2</a>
              <a href="/category3" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Category 3</a>
            </div>
          </div>
          <a href="/faq" className="text-black hover:underline">FAQ</a>
          <a href="/contact-us" className="text-black hover:underline">Contact Us</a>
          <a href="/blog" className="text-black hover:underline">Blog</a>
        </div>

        {/* Burger Menu (for mobile) */}
        <div className="md:hidden">
          <BurgerMenu
            right
            isOpen={isOpen}
            onStateChange={handleMenuStateChange}
            customBurgerIcon={<FaBars className="w-6 h-6 text-gray-700" />}
            customCrossIcon={<FaTimes className="w-6 h-6 text-gray-700" />}
            styles={{
              bmBurgerButton: { width: '36px', height: '30px', right: '24px', top: '24px' },
              bmMenuWrap: { position: 'fixed', height: '100%' },
              bmMenu: { background: '#fff', padding: '2.5em 1.5em', fontSize: '1.15em' },
              bmMorphShape: { fill: '#373a47' },
              bmItemList: { color: '#373a47', padding: '0.8em' },
              bmOverlay: { background: 'rgba(0, 0, 0, 0.3)' },
            }}
          >
            <a href="/" className="text-black block py-2 hover:underline">
              Home
            </a>
            <div className="relative">
              <button className="text-black block py-2 hover:underline">
                Categories
              </button>
              <div className="pl-4">
                <a href="/category1" className="block py-2 text-sm text-gray-700 hover:underline">Category 1</a>
                <a href="/category2" className="block py-2 text-sm text-gray-700 hover:underline">Category 2</a>
                <a href="/category3" className="block py-2 text-sm text-gray-700 hover:underline">Category 3</a>
              </div>
            </div>
            <a href="/faq" className="text-black block py-2 hover:underline">
              FAQ
            </a>
            <a href="/contact-us" className="text-black block py-2 hover:underline">
              Contact Us
            </a>
            <a href="/blog" className="text-black block py-2 hover:underline">
              Blog
            </a>
          </BurgerMenu>
        </div>
      </div>
    </nav>
  );
};

export default NavigationBar;
