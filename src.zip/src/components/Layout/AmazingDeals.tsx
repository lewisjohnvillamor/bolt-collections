import React from 'react';

const amazingDeals = [
  {
    name: "Daily Deals",
    description: "Save up to 25% on CellPhones",
    discount: "25% OFF",
    style: "bg-red-500 text-white",
    imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/09/homev6-deals.jpg?fit=340%2C340&ssl=1",
  },
  {
    name: "Save up to $99 on GoPro HERO9",
    description: "Save up to 25% on GoPro HERO9",
    discount: "Save",
    style: "bg-yellow-200 text-black",
    imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/09/homev6-saveupto25of.jpg?fit=340%2C340&ssl=1",
  },
  {
    name: "Clearance Sale",
    description: "Save up to $50 on Pixel Buds 2",
    discount: "Clearance",
    style: "bg-orange-500 text-white",
    imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/09/homev6-gopro.jpg?fit=340%2C340&ssl=1",
  },
  {
    name: "Sale",
    description: "Sale up to $50 on Pixel Buds 2",
    discount: "Sale",
    style: "bg-gray-400 text-white",
    imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/09/homev6-clearance.jpg?fit=340%2C340&ssl=1",
  },
  {
    name: "Extra 10% off Purchase of $300+",
    description: "Extra 10% Off",
    discount: "Extra 10% Off",
    style: "bg-pink-200 text-black",
    imgSrc: "https://i0.wp.com/motta.uix.store/electronic/wp-content/uploads/sites/6/2022/09/homev6-pixelbuds.jpg?fit=340%2C340&ssl=1",
  },
];

const AmazingDeals = () => {
  return (
    <div className="container mx-auto m-2 p-2">
        <div>
            {/* For larger screens (md and above) - keep "Our Featured Offers" at the top */}
            <div className="flex justify-between items-center mb-6 hidden sm:flex">
                <h2 className="text-2xl font-semibold">Discover These Amazing Deals</h2>
                <a href="#" className="text-sm text-blue-600 hover:underline">
                See All Deals
                </a>
            </div>

            {/* For mobile devices (sm and below) - move "Our Featured Offers" to the bottom */}
            <div className="flex flex-col items-center sm:hidden mt-6">
                <h2 className="text-2xl font-semibold">Discover These Amazing Deals</h2>
                <a href="#" className="text-sm text-blue-600 hover:underline">
                See All Deals
                </a>
            </div>
            </div>
{/* 
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold">Discover These Amazing Deals</h2>
        <a href="#" className="text-sm text-blue-600 hover:underline">
          See All Deals
        </a>
      </div> */}

      {/* Deals */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-5 gap-6">
        {amazingDeals.map((deal, idx) => (
          <div key={idx} className="flex flex-col items-center">
            {/* Image Circle */}
            <div className="relative rounded-full h-44 w-44 shadow-md hover:shadow-lg transition-shadow duration-300">
              <img
                src={deal.imgSrc}
                alt={deal.name}
                className="rounded-full h-full w-full object-cover"
              />
              {/* <div className="absolute top-4 left-4 text-white text-xl font-bold">
                {deal.discount}
              </div> */}
            </div>

            {/* Deal Information */}
            <div className="text-center mt-3">
              <p className="text-md font-semibold">{deal.name}</p>
              <p className="text-sm text-gray-600">{deal.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AmazingDeals;
