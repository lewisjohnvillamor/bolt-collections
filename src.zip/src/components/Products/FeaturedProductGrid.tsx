'use client';

import { useMemo } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import useProducts from '@/hooks/useProducts';
import ProductCard from './ProductCard';

const FeaturedProductGrid = () => {
  // Memoize the options object and use the correct type for sortKey
  const options = useMemo(
    () => ({
      search: '',
      sortKey: 'TITLE' as const, // Use 'as const' to make it a constant value
      reverse: false,
      first: 10,
    }),
    []
  );

  const { products, loading, error } = useProducts(options);

  if (loading) {
    return <p>Loading products...</p>;
  }

  if (error) {
    return <p>Error: {error}</p>;
  }

  if (products.length === 0) {
    return <p>No products found.</p>;
  }

  return (
    <div className="container mx-auto p-4">
      {/* Section Header */}
      <div className="flex justify-between items-center mb-6">
      <h2 className="text-2xl font-semibold">Today&apos;s Popular Picks</h2>
        <a href="#" className="text-sm text-blue-600 hover:underline">
          See All Products
        </a>
      </div>

      {/* Swiper for Featured Products */}
      <Swiper
        modules={[Navigation, Pagination]}
        spaceBetween={20}
        slidesPerView={2} // Show 2 products on mobile
        breakpoints={{
          // Settings for larger screens
          768: {
            slidesPerView: 4, // Show 4 products on larger screens
          },
        }}
        navigation={true}
        pagination={{ clickable: true }}
      >
        {products.map((product) => (
          <SwiperSlide key={product.id}>
            <ProductCard product={product} />
          </SwiperSlide>
        ))}
      </Swiper>

      {/* Banner on the right side */}
      <div className="mt-6 flex items-center justify-center lg:justify-between">
        <div className="bg-blue-100 p-8 rounded-lg text-center w-full lg:w-1/4">
          <h3 className="text-lg font-semibold mb-2">NEW ARRIVAL</h3>
          <h2 className="text-2xl font-bold mb-4">Galaxy Tab S7+</h2>
          <p>Meet the Galaxy Tab</p>
          <button className="bg-blue-500 text-white px-4 py-2 rounded mt-4">
            Buy Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default FeaturedProductGrid;
