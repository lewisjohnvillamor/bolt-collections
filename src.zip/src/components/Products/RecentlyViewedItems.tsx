'use client';

import { useMemo } from 'react';
import useProducts from '@/hooks/useProducts';
import ProductCard from './ProductCard';

const RecentlyViewedItems = () => {
  // Define allowed sortKey values
  type SortKey = 'TITLE' | 'PRODUCT_TYPE' | 'VENDOR' | 'CREATED_AT' | 'UPDATED_AT' | 'PUBLISHED_AT';

  const options = useMemo(() => ({
    search: '',
    sortKey: 'TITLE' as SortKey, // Correctly typing the sortKey
    reverse: false,
    first: 4, // Adjust the number of products to fetch
  }), []);

  const { products, loading, error } = useProducts(options);

  if (loading) return <p>Loading products...</p>;
  if (error) return <p>Error: {error}</p>;
  if (products.length === 0) return <p>No recently viewed products found.</p>;

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Recently Viewed Items</h2>
        <a href="/products" className="text-sm text-blue-500 hover:underline">
          See All Products
        </a>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 gap-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default RecentlyViewedItems;
