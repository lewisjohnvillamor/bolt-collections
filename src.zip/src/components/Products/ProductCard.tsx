'use client';
import Link from 'next/link';
import { ProductNode } from '@/types/product';
import { FaStar } from 'react-icons/fa'; // Import star icons for ratings

interface ProductCardProps {
  product: ProductNode;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const firstImage = product.images?.edges?.[0]?.node;
  const firstVariant = product.variants?.edges?.[0]?.node;

  return (
    <div className="border border-gray-300 rounded-lg shadow-lg p-4">
      {/* Product Image */}
      <div className="mb-4">
        <Link href={`/product/${product.id}`} className="block group">
          <div className="w-full h-40 relative">
            <img
              src={firstImage?.originalSrc || '/placeholder-image.png'}
              alt={firstImage?.altText || product.title}
              className="w-full h-full object-contain rounded-md group-hover:opacity-90 transition-opacity duration-300"
            />
          </div>
        </Link>
      </div>

      {/* Product Info */}
      <div className="text-center">
        <Link href={`/product/${product.id}`} className="block group">
          <h3 className="text-md font-semibold mb-1 text-gray-800 group-hover:text-blue-500 transition-colors duration-300 truncate">
            {product.title}
          </h3>
        </Link>

        {/* Ratings */}
        <div className="flex justify-center items-center space-x-1 text-yellow-500 mb-2">
          {/* Replace with dynamic stars and review counts */}
          <FaStar /> <FaStar /> <FaStar /> <FaStar /> <FaStar />
          <span className="text-sm text-gray-500">(15 Reviews)</span>
        </div>

        {/* Product Price and Fee */}
        <p className="text-xl font-bold text-black">
          ${firstVariant?.price || 'N/A'}
        </p>
        <p className="text-sm text-gray-500">+ $69.99 Programming Fee</p>
      </div>

      {/* Availability - Pickup In-Store and Shipping */}
      <div className="text-sm mt-4 space-y-2">
        <div className="flex justify-between items-center">
          <span className="font-semibold text-green-600">Pickup In-Store</span>
          <span className="text-gray-600">In stock at Anchorage</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="font-semibold text-gray-400">Ship to Home</span>
          <span className="text-gray-600">Not Available</span>
        </div>
      </div>

      {/* Quantity Selector and Add to Cart Button */}
      <div className="flex items-center mt-4 space-x-2">
        <input
          type="number"
          min="1"
          className="w-12 border border-gray-300 rounded text-center"
          defaultValue="1"
        />
        <button className="bg-orange-500 text-white font-semibold px-4 py-2 rounded-md hover:bg-orange-600 transition duration-300">
          Add to Cart
        </button>
      </div>

      {/* Compare Option */}
      <div className="mt-2 flex items-center justify-between">
        <label className="flex items-center space-x-1">
          <input type="checkbox" className="form-checkbox h-4 w-4" />
          <span className="text-sm text-gray-700">Compare</span>
        </label>
      </div>
    </div>
  );
};

export default ProductCard;
