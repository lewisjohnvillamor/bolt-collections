'use client';
import React, { useState } from 'react';
import { FaStar, FaCartPlus, FaShareAlt, FaPrint } from 'react-icons/fa';
import RecentlyViewedItems from './RecentlyViewedItems';

const ProductDetails = () => {
  // State for managing active tab in the accordion
  const [activeTab, setActiveTab] = useState<string>('Description');

  const handleTabClick = (tabName: string) => {
    setActiveTab(tabName === activeTab ? '' : tabName); // Toggle the active tab
  };

  return (
    <div className="container mx-auto p-4">
      {/* Breadcrumbs */}
      <nav className="text-sm text-gray-500 mb-4 flex space-x-2">
        <a href="#" className="hover:underline">Home</a>
        <span>/</span>
        <a href="#" className="hover:underline">Sports & Entertainment</a>
        <span>/</span>
        <a href="#" className="hover:underline">Football</a>
        <span>/</span>
        <span className="text-gray-900">KettlebellConnect 2.0 - Adjustable Kettlebell</span>
      </nav>

      {/* Product Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Product Image Slider */}
        <div>
          <div className="relative mb-4">
            <img 
              src="https://i0.wp.com/motta.uix.store/wp-content/uploads/2022/09/1-147.jpg?fit=1400%2C1400&ssl=1" 
              alt="KettlebellConnect 2.0"
              className="w-full h-auto object-cover"
            />
          </div>
          <div className="flex space-x-2">
            <img src="https://i0.wp.com/motta.uix.store/wp-content/uploads/2022/09/1-147.jpg?fit=100%2C100&ssl=1" alt="Product preview" className="w-16 h-16 object-cover cursor-pointer" />
            <img src="https://i0.wp.com/motta.uix.store/wp-content/uploads/2022/09/2-131.jpg?fit=100%2C100&ssl=1" alt="Product preview" className="w-16 h-16 object-cover cursor-pointer" />
            <img src="https://i0.wp.com/motta.uix.store/wp-content/uploads/2022/09/3-106.jpg?fit=100%2C100&ssl=1" alt="Product preview" className="w-16 h-16 object-cover cursor-pointer" />
          </div>
        </div>

        {/* Product Information */}
        <div>
          <h1 className="text-2xl font-bold mb-2">KettlebellConnect 2.0 - Adjustable Kettlebell - Cool Gray</h1>
          <p className="text-sm text-gray-600 mb-2">in Body Building</p>

          {/* Share and Print */}
          <div className="flex items-center space-x-4 mb-2 text-gray-500">
            <button className="hover:text-gray-900 flex items-center space-x-1">
              <FaShareAlt />
              <span>Share</span>
            </button>
            <button className="hover:text-gray-900 flex items-center space-x-1">
              <FaPrint />
              <span>Print</span>
            </button>
          </div>

          {/* Rating and Reviews */}
          <div className="flex items-center space-x-2 mb-4">
            <div className="flex text-yellow-500">
              <FaStar /><FaStar /><FaStar /><FaStar /><FaStar />
            </div>
            <span className="text-sm text-gray-500">5.00 (1 Review)</span>
          </div>

          {/* Price and Availability */}
          <p className="text-xl font-semibold text-green-600 mb-4">$119.00</p>
          <p className="text-green-600 font-medium mb-4">Available in stock</p>

          {/* Quantity Selector */}
          <div className="flex items-center space-x-2 mb-4">
            <button className="border px-4 py-2">-</button>
            <span>1</span>
            <button className="border px-4 py-2">+</button>
          </div>

          {/* Add to Cart and Buy Now Buttons */}
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4 mb-4">
            <button className="bg-blue-600 text-white px-4 py-2 flex items-center justify-center space-x-2">
              <FaCartPlus />
              <span>Add to Cart</span>
            </button>
            <button className="bg-gray-100 text-black px-4 py-2">Buy Now</button>
          </div>

          {/* Add to Compare and Wishlist */}
          <div className="flex space-x-4 text-gray-600">
            <button className="flex items-center space-x-1">
              <FaCartPlus />
              <span>Add To Compare</span>
            </button>
            <button className="flex items-center space-x-1">
              <FaCartPlus />
              <span>Add To Wishlist</span>
            </button>
          </div>

          {/* Store Information */}
          <div className="border-t border-gray-200 mt-4 pt-4">
            <div className="flex items-center space-x-4">
              <img src="path-to-store-logo.jpg" alt="Store logo" className="w-12 h-12 object-cover" />
              <div>
                <p className="text-sm text-gray-600">Store</p>
                <h4 className="font-semibold text-lg">TechciStore</h4>
                <div className="flex items-center text-yellow-500">
                  <FaStar /><FaStar /><FaStar /><FaStar /><FaStar />
                  <span className="text-sm text-gray-600 ml-2">(26 Reviews)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Free Shipping and Delivery Info */}
          <div className="mt-4 space-y-2">
            <div className="flex justify-between items-center text-sm text-gray-500">
              <p>Free Shipping & Returns on this item</p>
              <a href="#" className="text-blue-500 hover:underline">See Details</a>
            </div>
            <div className="flex justify-between items-center text-sm text-gray-500">
              <p>Delivery within 3-5 working days</p>
              <a href="#" className="text-blue-500 hover:underline">See Details</a>
            </div>
          </div>
        </div>
      </div>

      {/* Accordion for Description, Additional Info, Reviews, Shipping */}
      <div className="mt-8">
        {/* Tab Headers */}
        <div className="border-b border-gray-200 flex space-x-4">
          <button
            className={`py-2 text-gray-600 ${activeTab === 'Description' ? 'border-b-2 border-black text-black' : ''}`}
            onClick={() => handleTabClick('Description')}
          >
            Description
          </button>
          <button
            className={`py-2 text-gray-600 ${activeTab === 'Additional Information' ? 'border-b-2 border-black text-black' : ''}`}
            onClick={() => handleTabClick('Additional Information')}
          >
            Additional Information
          </button>
          <button
            className={`py-2 text-gray-600 ${activeTab === 'Reviews' ? 'border-b-2 border-black text-black' : ''}`}
            onClick={() => handleTabClick('Reviews')}
          >
            Reviews (1)
          </button>
          <button
            className={`py-2 text-gray-600 ${activeTab === 'Shipping & Returns' ? 'border-b-2 border-black text-black' : ''}`}
            onClick={() => handleTabClick('Shipping & Returns')}
          >
            Shipping & Returns
          </button>
        </div>

        {/* Tab Content */}
        <div className="py-4">
          {activeTab === 'Description' && (
            <div>
              <h2 className="text-xl font-bold mb-4">Product Description</h2>
              <p>This adjustable kettlebell is perfect for your fitness goals...</p>
            </div>
          )}

          {activeTab === 'Additional Information' && (
            <div>
              <h2 className="text-xl font-bold mb-4">Additional Information</h2>
              <p>This product is compatible with various fitness systems...</p>
            </div>
          )}

          {activeTab === 'Reviews' && (
            <div>
              <h2 className="text-xl font-bold mb-4">Reviews</h2>
              <p>Excellent product, I have been using it for a month...</p>
            </div>
          )}

          {activeTab === 'Shipping & Returns' && (
            <div>
              <h2 className="text-xl font-bold mb-4">Shipping & Returns</h2>
              <p>We offer free shipping on all items over $50...</p>
            </div>
          )}
        </div>
      </div>

      {/* Recently Viewed Items */}
      <div className="mt-8">
        <RecentlyViewedItems />
      </div>
    </div>
  );
};

export default ProductDetails;
