'use client';
import { useMemo } from 'react';
import useProducts from '@/hooks/useProducts';
import ProductCard from './ProductCard';

const ProductGrid = () => {
  // Memoize the options object and use the correct type for sortKey
  const options = useMemo(() => ({
    search: '',
    sortKey: 'TITLE' as const,
    reverse: false,
    first: 12, // Increased number of products displayed
  }), []);

  const { products, loading, error } = useProducts(options);

  if (loading) {
    return <p>Loading products...</p>;
  }

  if (error) {
    return <p>Error: {error}</p>;
  }

  if (products.length === 0) {
    return <p>No products found.</p>;
  }

  return (
    <div className="container mx-auto p-4">
      {/* Category Heading */}
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold">Key Fob Replacement Services</h1>
        <p className="text-lg">Save money, skip the dealership. Find the perfect fit for your vehicle!</p>
      </div>

      {/* Filters Section */}
      <div className="flex justify-between items-center mb-4">
        <button className="bg-gray-100 px-4 py-2 rounded-md">Filter</button>
        <p className="text-sm">{products.length} Products Found</p>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {/* Load More Button */}
      <div className="flex justify-center mt-6">
        <button className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-md">
          Load More
        </button>
      </div>
    </div>
  );
};

export default ProductGrid;
