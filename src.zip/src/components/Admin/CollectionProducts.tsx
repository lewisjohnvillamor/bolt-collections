import { useEffect, useState } from 'react';
import { ProductNode } from '@/types/product'; // Import ProductNode type
import axios from 'axios';

interface CollectionProductsProps {
  products: ProductNode[];
  setProducts: (products: ProductNode[]) => void;
}

const CollectionProducts: React.FC<CollectionProductsProps> = ({ products, setProducts }) => {
  const [availableProducts, setAvailableProducts] = useState<ProductNode[]>([]);

  useEffect(() => {
    // Fetch available products to display
    const fetchProducts = async () => {
      try {
        const response = await axios.get('/api/products'); // Adjust API endpoint accordingly
        const fetchedProducts: ProductNode[] = response.data.products.edges.map(
          (edge: { node: ProductNode }) => edge.node
        );
        setAvailableProducts(fetchedProducts);
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    };

    fetchProducts();
  }, []);

  const addProductToCollection = (product: ProductNode) => {
    setProducts([...products, product]); // Add product to collection
  };

  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Add Products to Collection</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {availableProducts.map((product) => (
          <div key={product.id} className="bg-white p-4 rounded shadow">
            <h4 className="text-md font-bold">{product.title}</h4>
            <p>{product.description}</p>
            <button
              className="bg-blue-500 text-white px-4 py-2 mt-2"
              onClick={() => addProductToCollection(product)}
            >
              Add to Collection
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CollectionProducts;
