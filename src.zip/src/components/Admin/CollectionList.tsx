'use client';

import Link from 'next/link';
import useCollections from '@/hooks/useCollections'; // Using the custom hook
import { Collection } from '@/types/collection'; // Ensure correct type import

const CollectionList = () => {
  const { collections, loading, error } = useCollections(); // Use the hook for fetching collections

  return (
    <div>
      <Link href="/admin/collections/new" className="text-blue-500 mb-4 block">
        Add New Collection
      </Link>

      {/* Display loading message */}
      {loading && <p>Loading collections...</p>}

      {/* Display error message */}
      {error && <p className="text-red-500">Error: {error}</p>}

      {/* Show message if there are no collections */}
      {!loading && !error && collections.length === 0 && (
        <p>No collections found.</p>
      )}

      {/* Display collections if they exist */}
      {!loading && !error && collections.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {collections.map((collection: Collection) => (
            <div key={collection._id} className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-semibold">{collection.name}</h2>
              <p className="text-gray-600 mt-2">{collection.description}</p>
              <Link
                href={`/admin/collections/${collection._id}`}
                className="text-blue-500 text-sm mt-4 block"
              >
                Edit Collection
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CollectionList;
