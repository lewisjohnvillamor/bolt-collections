import useCollectionForm from '@/hooks/useCollectionForm';
import CollectionProducts from './CollectionProducts';
import { Collection } from '@/types/collection';

const CollectionForm = ({ collection }: { collection?: Collection }) => {
  const {
    name, setName,
    description, setDescription,
    products, setProducts,
    seoTitle, setSeoTitle,
    seoDescription, setSeoDescription,
    bannerImage, setBannerImage,
    isVisible, setIsVisible,
    sortOrder, setSortOrder,
    rules, setRules,
    handleSave,
  } = useCollectionForm(collection);

  return (
    <div>
      <div className="mb-4">
        <label className="block text-gray-700">Name</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="border p-2 w-full"
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700">Description</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="border p-2 w-full"
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700">SEO Title</label>
        <input
          type="text"
          value={seoTitle}
          onChange={(e) => setSeoTitle(e.target.value)}
          className="border p-2 w-full"
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700">SEO Description</label>
        <textarea
          value={seoDescription}
          onChange={(e) => setSeoDescription(e.target.value)}
          className="border p-2 w-full"
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700">Banner Image URL</label>
        <input
          type="text"
          value={bannerImage}
          onChange={(e) => setBannerImage(e.target.value)}
          className="border p-2 w-full"
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700">Is Visible</label>
        <input
          type="checkbox"
          checked={isVisible}
          onChange={(e) => setIsVisible(e.target.checked)}
          className="mr-2"
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700">Sort Order</label>
        <input
          type="number"
          value={sortOrder}
          onChange={(e) => setSortOrder(Number(e.target.value))}
          className="border p-2 w-full"
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700">Rules - Product Type</label>
        <input
          type="text"
          value={rules.productType}
          onChange={(e) => setRules({ ...rules, productType: e.target.value })}
          className="border p-2 w-full"
        />
      </div>

      <CollectionProducts products={products} setProducts={setProducts} />

      <button onClick={handleSave} className="bg-blue-500 text-white px-4 py-2">
        Save Collection
      </button>
    </div>
  );
};

export default CollectionForm;
